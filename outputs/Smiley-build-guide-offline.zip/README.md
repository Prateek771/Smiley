# Smiley build guide

A static, private project handbook. This is the build roadmap and product-value explanation, not the Smiley hospital SaaS.

## Use

Open `dist/index.html` or serve `dist` with a static HTTP server. The deployed private Site is the preferred consistent address. All tasks start unchecked. Read any stage, finish its checklist, record evidence, then clear the stage. Editing prior work reopens dependent reviews.

Progress is stored in this browser and origin only. Export a JSON backup before switching browsers or moving from the local preview to the hosted Site. The export window also exposes copyable JSON for browsers that do not deliver downloads. Restore validates the roadmap version and known task IDs. No patient data belongs in this handbook.

## Files

- `dist/data.js`: eight stages, 50 tasks, six parallel validation tasks, decisions and references.
- `dist/app.js`: local progress, gates, navigation, backup/restore and optional WebMCP actions.
- `dist/pages.js`: product and validation explanations.
- `dist/styles.css`: responsive layout and print styles.
- `dist/downloads/`: the six-page value PDF and editable Markdown.
- `.openai/hosting.json`: static hosting configuration and the existing Sites project ID.

47 tasks cover a synthetic technical release. Three additional tasks require hospital permissions, expert validation and a distinct live-use decision. Checked boxes record a review; they do not certify compliance or real financial accuracy.

## Updating the plan

Keep stable task IDs when changing wording. Version the schema and migrate saved state if changing task identity or completion meaning. Keep the PDF, source notes, and scope changes aligned. Regenerate the data copy from `../work/roadmap-content.json` after editing that source.

No third-party JavaScript or application backend is used. Fonts load from Google Fonts with system fallbacks. Optional WebMCP tools use the same validated actions as the UI and save to the same browser state.
